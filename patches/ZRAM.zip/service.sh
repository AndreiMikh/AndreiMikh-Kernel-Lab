MODDIR=${0%/*}
CONFIG_FILE="$MODDIR/config.prop"

# Exit if the Configuration File Does Not Exist
if [ ! -f "$CONFIG_FILE" ]; then
  echo "Config.prop Not Found! Exiting"
  exit 1
fi

# Load Variables
. "$CONFIG_FILE"

# Check if the Variable is Defined
if [ -z "$ZRAM_ALGO" ] || [ -z "$ZRAM_SIZE" ]; then
  echo "ZRAM_ALGO or ZRAM_SIZE is not set! Exiting."
  exit 1
fi

# Delayed Startup (To Prevent the System from Not having Completed Initialization)
sleep 30

# Shutdown and Reset All Existing ZRAM Devices
for dev in /dev/block/zram*; do
  if [ -e "$dev" ]; then
    echo "Disabling $dev"
    swapoff "$dev" 2>/dev/null
    echo 1 > "/sys/block/$(basename "$dev")/reset"
  fi
done

# Try Uninstalling Module to Ensure a Clean State
if lsmod | grep -q "^zram"; then
  echo "Removing Existing ZRAM Module"
  rmmod zram
  sleep 1
fi

# Load the Custom ZSTDN Module (If it Exists)
if [ -f "$MODDIR/zram/zstdn.ko" ]; then
  su -c insmod "$MODDIR/zram/zstdn.ko"
fi

# Load the ZRAM Module (Once Only)
if ! lsmod | grep -q "^zram"; then
  su -c insmod "$MODDIR/zram/zram.ko"
else
  echo "ZRAM Module Already Loaded, Skipping"
fi

# Configure ZRAM0 (Make Sure There is Only One)
if [ -e /dev/block/zram0 ]; then
  sleep 5
  echo '1' > /sys/block/zram0/reset
  echo '0' > /sys/block/zram0/disksize
  echo '8' > /sys/block/zram0/max_comp_streams
  echo "${ZRAM_ALGO}" > /sys/block/zram0/comp_algorithm
  echo "${ZRAM_SIZE}" > /sys/block/zram0/disksize
  mkswap /dev/block/zram0 > /dev/null 2>&1
  swapon /dev/block/zram0 > /dev/null 2>&1
  echo "ZRAM0 is Now Active with ${ZRAM_ALGO} and Size ${ZRAM_SIZE}"
else
  echo "ZRAM0 Not Found, Failed to Initialize Swap"
  exit 1
fi

# Check if There are Any Spare ZRAM Devices
zram_count=$(ls /sys/block/ | grep -c '^zram')
if [ "$zram_count" -gt 1 ]; then
  echo "Warning: More Than One ZRAM Device Present!"
  ls /sys/block/ | grep '^zram'
fi
