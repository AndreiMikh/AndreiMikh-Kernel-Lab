# Automatically Obtain Module Name and Path
MODNAME="$(basename "$MODPATH")"
OLD_MODPATH="/data/adb/modules/$MODNAME"

# Current and Old Module ZRAM Paths
ZRAM_DIR="$MODPATH/zram"
OLD_ZRAM_DIR="$OLD_MODPATH/zram"

ui_print "========="
ui_print "Andrei"
ui_print "Mikhail"
ui_print "  "
ui_print "  "
ui_print "ZRAM Module"
ui_print "ZRAM Algorithm Support"
ui_print "========="

ui_print "Check if the ZRAM Folder for Installed Modules Exists..."

if [ -d "$OLD_ZRAM_DIR" ]; then
  ui_print "Old ZRAM Module Folder has been Detected, Copy and Retain Files..."
  mkdir -p "$ZRAM_DIR"
  cp -af "$OLD_ZRAM_DIR/." "$ZRAM_DIR/"
  ui_print "✅ File Copy Completed"
else
  ui_print "No Old ZRAM Module Folder Detected, Skip Copying..."
fi
